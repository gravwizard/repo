import os, xbmc, xbmcaddon

#########################################################
### User Edit Variables #################################
#########################################################
ADDON_ID       = xbmcaddon.Addon().getAddonInfo('id')
ADDONTITLE     = 'Gravity Cleaner'
EXCLUDES       = [ADDON_ID, 'repository.pulsecleaner-1.0.1']
# Text File with build info in it.
BUILDFILE      = 'http://nothere.th/ankyou/mbuilds.xml'
COMMFILE	   = 'http://nothere.th/ankyou/cbuilds.xml'
SKINFILE	   = 'http://nothere.th/ankyou/sbuilds.xml'

# How often you would list it to check for build updates in days
# 0 being every startup of kodi
UPDATECHECK    = 0
# Text File with apk info in it.
APKFILE        = 'http://nothere.th/ankyou/apks.txt'

# Dont need to edit just here for icons stored locally
HOME           = xbmc.translatePath('special://home/')
PLUGIN         = os.path.join(HOME,     'addons',    ADDON_ID)
ART            = os.path.join(PLUGIN,   'resources', 'art')

#########################################################
### THEMING MENU ITEMS ##################################
#########################################################
ICONMAINT      = 'special://home/addons/plugin.program.gravitycleaner/icon.png'
ICONBUILDS     = 'http://'
ICONCONTACT    = 'http://'
ICONSAVE       = 'http://'
ICONTRAKT      = 'http://'
ICONREAL       = 'http://'
ICONLOGIN      = 'http://'
ICONAPK        = 'http://'
ICONSETTINGS   = 'http://'
# Hide the ====== seperators 'Yes' or 'No'
HIDESPACERS    = 'No'                                                                    

# You can edit these however you want, just make sure that you have a %s in each of the
# THEME's so it grabs the text from the menu item
COLOR1         = 'aqua'
COLOR2         = 'white'
COLOR3         = 'aqua'
COLOR4         = 'green'

# Primary menu items   / %s is the menu item and is required
THEME1         = '[COLOR '+COLOR1+'][COLOR '+COLOR2+'] [/COLOR][/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'    
# Build Names          / %s is the menu item and is required
THEME2         = '[COLOR '+COLOR1+']%s[/COLOR]'                                          
# Alternate items      / %s is the menu item and is required
THEME3         = '[COLOR '+COLOR2+']%s[/COLOR]'                                          
# Current Build Header / %s is the menu item and is required
THEME4         = '[COLOR aqua][B][Current Installed Build][/B][/COLOR] [COLOR red]%s[/COLOR]' 
# Current Theme Header / %s is the menu item and is required
THEME5         = '[COLOR '+COLOR2+']  Current Theme:[/COLOR] [COLOR '+COLOR1+']%s[/COLOR]' 
# Alternate items      / %s is the menu item and is required
THEME6         = '[COLOR '+COLOR3+']%s[/COLOR]'                                          
THEME7         = '[COLOR '+COLOR4+']%s[/COLOR]'                                          

# Message for Contact Page
# Enable 'Contact' menu item 'Yes' hide or 'No' dont hide
HIDECONTACT    = 'yes'                                                                    
# You can add \n to do line breaks
CONTACT        = 'Thank You'
#########################################################

#########################################################
### AUTO UPDATE #########################################
########## FOR THOSE WITH NO REPO #######################
# Enable Auto Update 'Yes' or 'No'
AUTOUPDATE     = 'No'                                                                    
# Url to wizard version
WIZARDFILE     = ''                          
#########################################################

#########################################################
### AUTO INSTALL ########################################
########## REPO IF NOT INSTALLED ########################
# Enable Auto Install 'Yes' or 'No'
AUTOINSTALL    = 'No'                                                                    
# Addon ID for the repository
REPOID         = 'repository.pulsecleaner'
# Url to Addons.xml file in your repo folder(this is so we can get the latest version)
REPOADDONXML   = 'http://nothere.th/ankyou/pulsecleanerrepo/repository.pulsecleaner/addon.xml'
# Url to folder zip is located in
REPOZIPURL     = 'http://nothere.th/ankyou/repo/'
#########################################################

#########################################################
### NOTIFICATION WINDOW##################################
#########################################################
# Enable Notification screen Yes or No
ENABLE         = 'No'
# Url to notification file
NOTIFICATION   = 'http://nothere.th/ankyou/notify.txt'
# Use either 'Text' or 'Image'
HEADERTYPE     = 'Text'
# Font size of header
FONTHEADER     = 'Font14'
HEADERMESSAGE  = 'Gravity Cleaner'
# url to image if using Image 424x180
HEADERIMAGE    = ''
# Font for Notification Window
FONTSETTINGS   = 'Font13'
# Background for Notification Window
BACKGROUND     = ''
#########################################################